   <?php
	    define("DB_HOST", "localhost");
	    define("DB_USER", "root"); #needs change on host
	    define("DB_PASS", ""); 
	    define("DB_NAME", "kealcom_newsletter1");
    ?>