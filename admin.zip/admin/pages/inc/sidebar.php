            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Charts<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="InsertImage.php">Insert Image</a>
                                </li>
                                <li>
                                    <a href="InsertVideo.php">Insert Video</a>
                                </li>
                                 <li>
                                    <a href="insertPost.php">Insert Post</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

                        <li>
                            <a href="#"><i class="fa fa-cog" aria-hidden="true"></i> Control<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="controlimage.php">Control Image</a>
                                </li>
                                <li>
                                    <a href="controlVideo.php">Control Video</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-user" aria-hidden="true"></i> User Control<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="controlimage.php">Control Image</a>
                                </li>
                                <li>
                                    <a href="controlVideo.php">Control Video</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-user" aria-hidden="true"></i> FileStoring<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="register.php">Create User</a>
                                </li>

                                 <li>
                                    <a href="insertf.php">Insert Files</a>
                                </li>
                                 <li>
                                    <a href="clientlist.php">Client List</a>
                                </li>
                                <li>
                                    <a href="commonFiles.php">Upload Common Files</a>
                                </li>
                                </ul>
                                </li>
                         <li>
                            <a href="#"><i class="fa fa-envelope" aria-hidden="true"></i>  P-Blasting<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="ymail.php">Inbox</a>
                                </li>
                                <li>
                                    <a href="campagin.php">Campagin Name</a>
                                </li>   
                                <li>
                                    <a href="sblast.php">Start Blasting</a>
                                </li>      
                                
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <!-- <li>
                            <a href="tables.php"><i class="fa fa-table fa-fw"></i> Tables</a>
                        </li> -->
                        
                        
                        
                        
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
