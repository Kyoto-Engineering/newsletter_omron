<?php include "inc/header.php";?>
<?php include "inc/sidebar.php";?>
        <div id="page-wrapper">
            
        <div class="row">
        <h3></h3>
        <div class="class" style="width: 40%;
margin: 0 auto;
background-color: #d8d9db;
padding: 20px 15px;
border-radius: 6px;
border: 1px solid #c6bdbd;">
            <form>
                                 <div class="form-group row">
                                    <p></p>
                                    <div class="col-md-9">
                                        <input type="text" name="picName" class="form-control" placeholder="Enter Image Name">
                                    </div>
                                </div>
                        <div class="form-group row">
                                <div class="col-md-4"></div>
                                    <div class="col-md-4">
                                        <button type="submit" name="submit" class="btn btn-primary">Create Name</button>
                                    </div>
                                    <div class="col-md-4"></div>
                                </div>
            </form>

        </div>
</div>
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
<?php include "inc/footer.php";?>