<?php include "inc/header.php";?>
<?php include "inc/sidebar.php";?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Dashboard</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
                <div class="row">
                    <div class="panelbox">
                    <p><a href="section_01.php"><img class="img-responsive pic" src="../images/photo-album-icon-png-14.png"></a></p>
                        &nbsp;
                       <p><a href="section_02.php"><img class="img-responsive pic" src="../images/Code-Optimization-256x256.png"></a></p> 
                    </div>
                </div>
            <!-- /.row -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
<?php include "inc/footer.php";?>